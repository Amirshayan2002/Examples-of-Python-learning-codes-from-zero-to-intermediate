x = 4       # x is of type int
x = "ali" # x is now of type str
print(x)