a = "Hello , World!"
print(a.split(',')) 