txt = "150"
x = txt.zfill(7)
print(x)
