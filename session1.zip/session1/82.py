txt = "banana"
x = txt.center(20)
print(x)