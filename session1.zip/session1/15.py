x = "ali"
# is the same as
y = 'ali'
print(x , "  " ,y)
