x = bool(5)

#display x:
print(x)

#display the data type of x:
print(type(x)) 
