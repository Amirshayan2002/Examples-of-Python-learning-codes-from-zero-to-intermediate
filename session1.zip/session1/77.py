a = " Hello, World! "
print(a.strip()) 
