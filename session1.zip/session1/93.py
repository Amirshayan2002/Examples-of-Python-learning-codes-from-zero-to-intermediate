txt = "     banana     "
x = txt
print("of all fruits", x , "is my favorite")
x = txt.rstrip()
print("of all fruits", x , "is my favorite")
x = txt.lstrip()
print("of all fruits", x , "is my favorite")