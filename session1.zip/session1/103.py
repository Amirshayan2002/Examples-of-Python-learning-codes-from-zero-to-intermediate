string_one = "Artificial Neural Network"
print("string one: " + string_one)
print(string_one.islower())

string_two = string_one.lower()  # converts string to lowercase
print("string two: " + string_two)
print(string_two.islower())

string_three = string_one.upper() # converts string to uppercase
print("string three: " + string_three)
print(string_three.isupper())

print("string one: " + string_one)
print(string_one.istitle())
