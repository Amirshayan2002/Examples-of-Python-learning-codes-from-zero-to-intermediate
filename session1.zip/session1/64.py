txt = "The best things in life are free!"
print("free" in txt)