txt = "Hello, welcome to my world."
x = txt.index("welcome")
print(x)