x = 5
y = "ali"
print(x)
print(y)
