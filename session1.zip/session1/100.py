"""
    Arithmetic operators
    +    -    *    /    %    **    //
    Assignment operators
    =   +=   -=    *=     /=    %=    **=    //=   &=    |=    ^=   >>=    <<=   
    Comparison operators
    ==   !=   >    <   >=    <=     
    Logical operators
    and    or    not  
    Identity operators
    is     is not
    Membership operators
    in     not in
    Bitwise operators
    &     |     ^     ~    <<   >>
    
"""