print("Hello")
print('Hello')