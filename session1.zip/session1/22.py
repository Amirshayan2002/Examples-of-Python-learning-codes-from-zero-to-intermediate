x = "Python is awesome"
print(x)
