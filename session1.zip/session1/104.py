string = "ali reza sasan ramin mohammad"

s = string.split()[::-1]
print(s)

l = []
for i in s:
    l.append(i)
print(" ".join(l))