txt = "hello, and welcome to my world."
x = txt.capitalize()
print (x)
txt = "36 is my age."
x = txt.capitalize()
print (x)
