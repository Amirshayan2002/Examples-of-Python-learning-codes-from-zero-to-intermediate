a = 4
A = "ali"
#A will not overwrite a
print(a,"  ",A)