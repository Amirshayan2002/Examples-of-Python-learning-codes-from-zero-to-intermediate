myTuple = ("ali", "reza", "hassani")
x = "_".join(myTuple)
print(x)