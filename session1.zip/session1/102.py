decimal_rep_ascii = [90,91,92,93,94,95,96,97]

for one_decimal in decimal_rep_ascii:
    print(chr(one_decimal))