a = "Hello"
print(a)