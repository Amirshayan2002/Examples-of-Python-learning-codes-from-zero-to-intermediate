a = "Hello, World!"
print(a.replace("H", "J"))
