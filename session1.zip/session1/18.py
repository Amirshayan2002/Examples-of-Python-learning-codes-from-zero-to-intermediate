myVariableName = "ali"
MyVariableName = "reza"
my_variable_name = "ramin"
print(myVariableName,"   ",MyVariableName,"   ",my_variable_name)
