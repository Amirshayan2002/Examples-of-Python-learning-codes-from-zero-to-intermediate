txt = "Hello, And Welcome To My World!"
x = txt.casefold()
print(x)