txt = "Hello, welcome to my world."
x = txt.startswith("Hello")
y = txt.endswith("ld.")
print(x)
print(y)