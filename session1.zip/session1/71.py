b = "Hello, World!"
print(b[-5:-2])