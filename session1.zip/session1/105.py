
test_str = 'amirhossain'
print("The original string is : " + str(test_str))
half_index = len(test_str) // 2
 
res = ''
for i in range(len(test_str)):
    if i >= half_index:
      res += test_str[i].upper()
    else :
      res += test_str[i]
         
print("The resultant string : " + str(res))