txt = "Hello, welcome to my world."
x = txt.find("welcome")
print(x)