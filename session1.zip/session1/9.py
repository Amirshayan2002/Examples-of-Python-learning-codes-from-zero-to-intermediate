#print("Hello, World!")
print("Cheers, Mate!")