txt = "Company12"
x = txt.isalnum()
print(x)
txt = "Company"
x = txt.isalnum()
print(x)
txt = "12"
x = txt.isalnum()
print(x)
txt = "Com+pany12"
x = txt.isalnum()
print(x)


