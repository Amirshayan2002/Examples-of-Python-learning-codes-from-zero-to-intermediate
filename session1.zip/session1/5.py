x = 5
y = "Hello, World!"
print(x,"     ",y)