x = 5
y = "ali"
print(type(x))
print(type(y))