if 5 > 2:
  print("Five is greater than two!")