x = 1    # int
y = 2.8  # float
z = 1j   # complex
print(x ,"   ", y,"   ", z)
print(type(x))
print(type(y))
print(type(z))