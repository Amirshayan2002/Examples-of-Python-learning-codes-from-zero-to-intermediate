x = dict(name="ali", age=36)

#display x:
print(x)

#display the data type of x:
print(type(x)) 
