x = int(20)

#display x:
print(x)

#display the data type of x:
print(type(x)) 
