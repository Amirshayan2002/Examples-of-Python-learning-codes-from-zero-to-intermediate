a = '''salam omidvaram haleton khob bashe
       arezoye salamati daram baraton
       mamnon babat paygiri shoma
ba tashakor '''
print(a)