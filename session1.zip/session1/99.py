x = 200
print(isinstance(x, int))