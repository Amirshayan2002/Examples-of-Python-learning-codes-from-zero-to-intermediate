txt = "50800"
x = txt.isdigit()
print(x)
txt = "50800 7"
x = txt.isdigit()
print(x)