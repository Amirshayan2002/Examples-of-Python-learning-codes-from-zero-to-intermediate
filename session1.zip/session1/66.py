txt = "The best things in life are free!"
print("expensive" not in txt)