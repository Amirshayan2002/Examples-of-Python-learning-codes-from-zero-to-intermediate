txt = "I love apples, apple are my favorite fruit"
x = txt.count("apple")
print(x)