myvar = "ali"
my_var = "reza"
_my_var = "ramin"
myVar = "hassan"
MYVAR = "mohammad"
myvar2 = "sasan"
print(myvar,"  ",my_var,"  ",_my_var,"  ",myVar,"  ",MYVAR,"  ",myvar2)
