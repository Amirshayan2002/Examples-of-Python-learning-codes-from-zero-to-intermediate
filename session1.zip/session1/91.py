txt = "Thank you for the music\nWelcome to the jungle"
x = txt.splitlines()
print(x)