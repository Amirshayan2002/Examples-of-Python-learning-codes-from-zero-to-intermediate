x = 1.10
y = 1.0123456789105432656213
z = -35.59
print(x,"  ",y,"  ",z)
print(type(x))
print(type(y))
print(type(z))