import string

ascii_upper_case = string.ascii_uppercase  # Output: ABCDEFGHIJKLMNOPQRSTUVWXYZ
s = ""
for one_letter in ascii_upper_case[:]:  
    s += str(ord(one_letter))+" "
print(s)

ascii_lower_case = string.ascii_lowercase  # Output: abcdefghijklmnopqrstuvwxyz
s = ""
for one_letter in ascii_lower_case[:]:  
    s += str(ord(one_letter))+" "
print(s)