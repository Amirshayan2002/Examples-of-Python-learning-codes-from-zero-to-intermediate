print(10 > 9)
print(10 == 9)
print(10 < 9)