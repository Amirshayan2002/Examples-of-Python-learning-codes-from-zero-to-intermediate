txt = "CompanyX"
x = txt.isalpha()
print(x)
txt = "CompanyX1"
x = txt.isalpha()
print(x)