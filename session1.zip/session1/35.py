x = complex(1j)

#display x:
print(x)

#display the data type of x:
print(type(x)) 
