txt0 = "For only {price:.2f} dollars!"
print(txt0.format(price = 49))
txt1 = "My name is {fname}, I'm {age}".format(fname = "ali", age = 36)
print(txt1)
txt2 = "My name is {0}, I'm {1}".format("ali",36)
print(txt2)
txt3 = "My name is {}, I'm {}".format("ali",36)
print(txt3)
txt3 = "My name is {1}, I'm {0}".format(36,"ali")
print(txt3)
txt4 = "We have {:<8} chickens."
print(txt4.format(49))
txt5 = "We have {:>8} chickens."
print(txt5.format(49))
txt6 = "We have {:^8} chickens."
print(txt6.format(49))
txt7 = "The universe is {:,} years old."
print(txt7.format(13800000000))


